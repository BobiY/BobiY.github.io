

(function(){
    var ele = document.getElementById('backTop');
    ele.onclick = function(e){
        document.body.scrollTop = 0;
    }
})()